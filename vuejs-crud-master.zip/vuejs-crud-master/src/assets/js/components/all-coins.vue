<template>
    <div id="all-coins">
        <h1>All Coins</h1>

        <div class="form-group">
            <input type="text" name="search" v-model="coinSearch" placeholder="Search coins" class="form-control" v-on:keyup="searchCoins">
        </div>

<div class="row">
      <div
        class="col-sm-12 col-md-6 col-lg-4"
        v-for="coin in coins"
        :key="coin.id"
        >
        <div class="card">
         <img :src="coin.image" class="card-img-top" alt="Coin image">
          <div class="card-body">
            <h5 class="card-title">{{ coin.name }}</h5>
            <p class="card-text">{{ coin.description }}</p>
            <p class="card-text">{{ coin.price }}</p>
            <div class="btn-group" role="group">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

    export default{
        data(){
            return{
                coins: [],
                originalCoins: [],
                coinSearch: ''
            }
        },

        created: function()
        {
            this.fetchCoinData();
        },

        methods: {
            fetchCoinData: function()
            {
                this.$http.get('http://localhost:3000/api/coins').then((response) => {
                    this.coins = response.body;
                    this.originalCoins = this.coins;
                }, (response) => {

                });
            },

            searchCoins: function()
            {
                if(this.coinSearch == '')
                {
                    this.coins = this.originalCoins;
                    return;
                }

                var searchedCoins = [];
                for(var i = 0; i < this.originalCoins.length; i++)
                {
                    var coinName = this.originalCoins[i]['name'].toLowerCase();
                    if(coinName.indexOf(this.coinSearch.toLowerCase()) >= 0)
                    {
                        searchedCoins.push(this.originalCoins[i]);
                    }
                }

                this.coins = searchedCoins;
            }
        }
    }
</script>

<style scoped>
.card {
  margin-bottom: 1.5rem;
  border: 1px solid #e2e2e2;
}
.card-img-top {
  width: 10rem;
  height: auto; /* para mantener la proporción de la imagen */
}
</style>