#VueJS Crud Example Application
This application is an example build of creating CRUD pages using VueJS and accessing data via an API.

# Install
    > npm install

The API used in this example is a Node.js express API.

# Run
    > npm run dev
    
Navigation to http://localhost:8080 to view the site
    
# Start API

To start the API open your command terminal to this location and enter

    > node server.js
    
API is now active on http://localhost:3000
   
# VUEJS-CRUD-MASTER
